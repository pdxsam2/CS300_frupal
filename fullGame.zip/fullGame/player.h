#include <iostream>

class Player
{
	public:
		
		Player()
		{
			for (int i = 0; i < 5; i++)
			{
				bag[i] = 0;
			}
			energy = 0;
			money = 0;
			jewel = 0;
		}
		
		void setData(int x, int y)
		{
			energy = x;
		    money = y;
		}
		
		void playerInfo()
		{
			cout << "Energy: " << energy << " Money: " << money << " Jewel: " << jewel << endl;
			cout << "Bagpack: ";
			if (bag[0] == 1)
			{
				cout << "Weed Whacker  ";		
			}
			if (bag[1] == 1)
			{
				cout << "Jack hammer  ";	
			}
			if (bag[2] == 1)
			{
				cout << "Pocket knife  ";	
			}
			if (bag[3] == 1)
			{
				cout << "Boat  ";	
			}
			if (bag[4] == 1)
			{
				cout << "Telescope  ";	
			}
			cout << endl;
			cout << endl;
		}
	
	protected:
		
		int energy;
		int money;
		int bag[5];
		int jewel;
};
