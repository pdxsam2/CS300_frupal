// Yichao Sun
// 1/29

#include <iostream>
#include "map.h" 
#include "mainControl.h" 

int main()
{
	cout << "*************** Welcome to Frupal Game ***************" << endl;
	cout << endl;
	
	int choice = 0;
	
	while (choice != 4)
	{
		cout << "************************ Menu ************************" << endl;
		cout << endl;
		cout << "1 Start the game!" << endl;
		cout << "2 Game rules" << endl;
		cout << "3 Map guiding" << endl;
		cout << "4 Quit" << endl;
		cout << endl;	
		cout << "Enter your choice: ";
		cin >> choice;	
		cout << endl;
		
		cin.clear();
		cin.ignore(100,'\n');
		
		if (choice == 3)
		{
			Map testMap;
			testMap.settingMap(6);
			testMap.printMap();
		}
		else if (choice == 2)
		{
			cout << "********************* Game Rules *********************" << endl;
			cout << endl;
			cout << "Find all 7 jewels on the island" << endl;
			cout << "If you run out of energy, the game will fail" << endl;
			cout << "Moving 1 space will takes 1 points of energy" << endl;
			cout << "Crossing bog and forest takes 2 points of energy" << endl;
			cout << "Breaking an obstacle with hands takes 1 point of energy" << endl;
			cout << "Breaking an obstacle with tools takes 0 point of energy" << endl;
			cout << "You cannot cross water if you don't have boat" << endl;
			cout << "Stores can buy boats and tools, bars can recover energy" << endl;
			cout << "Initial money and energy are defined by the player" << endl;
			cout << endl;
		}
		else if (choice == 1)
		{
			MainControl gameMainControl;
		}
	}
	
	
	
	return 0;	
} 
