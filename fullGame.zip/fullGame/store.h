#include <iostream>

using namespace std;

class Store
{
	public:
		
		Store()
		{
			for (int i = 0; i < 5; i++)
			{
				price[i] = 0;
			}
		}
		
		void getPrice(int price1, int price2, int price3, int price4, int price5)
		{
			price[0] = price1;
			price[1] = price2;
			price[2] = price3;
			price[3] = price4;
			price[4] = price5;
		}
		
		int visitStore(int & money)
		{			
			int choice;
			while (true)
			{
				cout << " ********** Store ********** " << endl;
				cout << endl;
				cout << "1 Weed Whacker (for bushes) " << price[0] << endl;
				cout << "2 Jack hammer (for rocks) " << price[1] << endl;
				cout << "3 Pocket knife (for trees) " << price[2] << endl;
				cout << "4 Boat " << price[3] << endl;
				cout << "5 Telescope " << price[4] << endl;
				cout << endl;
				cout << "What would you like? ";
				cin >> choice;	
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');	
				
				if ((choice != 1) && (choice != 2) && (choice != 3) && (choice != 4) && (choice != 5))
				{
					
				}
				else
				{
					if ((money - price[choice - 1]) < 0)
					{
						cout << "No enough money!" << endl;
						return 0;
					}
					else
					{
						cout << "Purchased!" << endl;
						money -= price[choice - 1];
						return choice;
					}
				}
			}	
		}
		
		bool visitBar(int & money)
		{
			char drink;
			cout << "Do you want to spend 500 dollars to buy a drink to gain 60 points energy (Y/N)? ";
			cin >> drink;
			cin.clear();
			cin.ignore(100,'\n');
					
			while ((drink != 'Y') && (drink != 'y') && (drink != 'N') && (drink != 'n'))
			{
				cout << "Wrong input, please re-enter: ";
				cin >> drink;
				cin.clear();
				cin.ignore(100,'\n');
			}	
			
			if ((drink == 'N') || (drink == 'n'))
			{
				return 0;
			} 
			else
			{
				if ((money - 500) < 0)
				{
					cout << "No enough money!" << endl;
					return 0;
				}
				else
				{
					cout << "Purchased!" << endl;
					money -= 500;
					return 1;
				}				
			}
		}
	
	private:
	
		int price[5];		
};


