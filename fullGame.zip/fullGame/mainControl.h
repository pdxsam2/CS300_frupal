#include <iostream>
#include "player.h"
#include "store.h"

class MainControl: public Player, public Store, public Map
{
	public:
		
		MainControl()
		{
			cout << "********** Setting ********** " << endl;
			cout << endl;
	
			int energy = -1;
			while (energy < 0)
			{
				cout << "How much for the initial energy (recommend 120)? ";
				cin >> energy;
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');
			}
			
			int money = -1;
			while (money < 0)
			{
				cout << "How much for the initial money (recommend 3000)? ";
				cin >> money;
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');
			}
			
			setData(energy,money);
					
			int price1 = -1;
			while (price1 < 0)
			{
				cout << "How much dose weed whacker cost (recommond 1000)? ";
				cin >> price1;
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');
			}

			int price2 = -1;
			while (price2 < 0)
			{
				cout << "How much dose jack hammer cost (recommond 1000)? ";
				cin >> price2;
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');
			}
			
			int price3 = -1;
			while (price3 < 0)
			{
				cout << "How much dose pocket knife cost (recommond 1000)? ";
				cin >> price3;
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');
			}
			
			int price4 = -1;
			while (price4 < 0)
			{
				cout << "How much dose boat cost (recommond 1500)? ";
				cin >> price4;
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');
			}
			
			int price5 = -1;
			while (price5 < 0)
			{
				cout << "How much dose telescope cost (recommond 1500)? ";
				cin >> price5;
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');
			}
			
			getPrice(price1, price2, price3, price4, price5);
			
			int difficulty = -1;
			while ((difficulty != 1) && (difficulty != 2) && (difficulty != 3) && (difficulty != 4) && (difficulty != 5))
			{
				cout << "Set the difficulty of the game (1-5, 1 is the hardest. this number will determine the number of obstacles)? ";
				cin >> difficulty;
				cout << endl;
				cin.clear();
				cin.ignore(100,'\n');
			}
			
			difficulty += 3;
			settingMap(difficulty);	
			
			x = rand() % 40 + 5;
			y = rand() % 40 + 5;
			
			setAllDark();
			setPlayer(x,y);
			
			cout << "All set!" << endl;
			cout << endl;
			
			gameProcess();
		}
		
		void gameProcess()
		{
			while ((energy != 0) && (jewel != 7))
			{
				printMap();
				playerInfo();
				
				
				char move;
				cout << "Input WSAD to move around: ";
				cin >> move;
				cin.clear();
				cin.ignore(100,'\n');		
				while ((move != 'A') && (move != 'a') && (move != 'S') && (move != 's') && (move != 'D') && (move != 'd') && (move != 'W') && (move != 'w'))
				{
					cout << "Wrong input, please re-enter: ";
					cin >> move;
					cin.clear();
					cin.ignore(100,'\n');
				}	
				
				int xTemp;
				int yTemp;
				
				if ((move == 'w') || (move == 'W'))
				{
					xTemp = x - 1;
					yTemp = y;
				}
				else if ((move == 's') || (move == 'S'))
				{
					xTemp = x + 1;
					yTemp = y;
				}
				else if ((move == 'd') || (move == 'D'))
				{
					xTemp = x;
					yTemp = y + 1;
				}
				else if ((move == 'a') || (move == 'A'))
				{
					xTemp = x;
					yTemp = y - 1;
				}
				
				
				if (map[xTemp][yTemp][0] == 'L')
				{
					map[x][y][1] = '0';
					x = xTemp;
					y = yTemp;
					energy--;
				}
				else if (map[xTemp][yTemp][0] == 'W')
				{
					if (bag[3] == 1)
					{
						map[x][y][1] = '0';
						x = xTemp;
						y = yTemp;
					}
					else
					{
						cout << "You don't have boat!" << endl;
					}
				}
				else if (map[xTemp][yTemp][0] == 'G')
				{
					map[x][y][1] = '0';
					x = xTemp;
					y = yTemp;
					energy--;
					energy--;
				}
				else if (map[xTemp][yTemp][0] == 'F')
				{
					map[x][y][1] = '0';
					x = xTemp;
					y = yTemp;
					energy--;
					energy--;
				}
				else if (map[xTemp][yTemp][0] == 'T')
				{
					map[x][y][1] = '0';
					x = xTemp;
					y = yTemp;
					
					if (bag[2] == 1)
					{
						energy--;
					}
					else
					{
						energy--;
						energy--;
					}
				}
				else if (map[xTemp][yTemp][0] == 'B')
				{
					map[x][y][1] = '0';
					x = xTemp;
					y = yTemp;
					
					if (bag[0] == 1)
					{
						energy--;
					}
					else
					{
						energy--;
						energy--;
					}
				}
				else if (map[xTemp][yTemp][0] == 'R')
				{
					map[x][y][1] = '0';
					x = xTemp;
					y = yTemp;
					
					if (bag[1] == 1)
					{
						energy--;
					}
					else
					{
						energy--;
						energy--;
					}
				}
				else if (map[xTemp][yTemp][0] == '3')
				{
					map[x][y][1] = '0';
					x = xTemp;
					y = yTemp;
					jewel++;
					energy--;
					cout << "Get one jewel!" << endl;
				}
				else if (map[xTemp][yTemp][0] == '1')
				{			
					int item = visitStore(money) - 1;
					bag[item] = 1;
				}
				else if (map[xTemp][yTemp][0] == '2')
				{			
					bool drink = visitBar(money);
					if (drink)
					{
						energy += 60;
					}
				}
				
				if (bag[4] == 1)
				{
					setPlayerSuper(x,y);
				}
				else
				{
					setPlayer(x,y);
				}
				
				cout << endl;
			}
			
			if (energy == 0)
			{
				cout << "You had ran out of the energy, the game is over!" << endl;
			}
			else
			{
				cout << "Congraulation, you found all jewels!" << endl;
			}
			cout << endl;
		}
		
	private:
		
		int x;
		int y;
};
