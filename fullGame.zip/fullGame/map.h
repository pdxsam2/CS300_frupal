#include <iostream>
#include <stdio.h>
#include <windows.h>

using namespace std;

class Map
{
	public:
		
		Map();	
		void settingMap(int value);
		void printMap();
		void buildLand();
		void buildObstacles(int value);
		void placeStore();
		void mapGuiding();
		
		void setAllDark();
		void setPlayer(int x, int y);
		void setPlayerSuper(int x, int y);
		

	
	protected:
	
		char map[50][50][3];	
};


