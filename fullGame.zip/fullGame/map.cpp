#include "map.h" 

Map::Map()
{
	for (int i = 0; i < 50; i++)
		{
			for (int j = 0; j < 50; j++)
			{
				map[i][j][0] = 'W';
				map[i][j][1] = '0';	
				map[i][j][2] = '0';
			}
		}
}

void Map::settingMap(int value)
{
	buildLand();
	buildObstacles(value);
	placeStore();	
}

void Map::buildLand()
{
	for (int i = 5; i < 45; i++)
	{
		for (int j = 5; j < 45; j++)
		{
			map[i][j][0] = 'L';
		}
	}
	
	for (int i = 10; i < 20; i++)
	{
		for (int j = 10; j < 20; j++)
		{
			map[i][j][0] = 'F';
		}
	}	
	
	for (int i = 30; i < 40; i++)
	{
		for (int j = 30; j < 40; j++)
		{
			map[i][j][0] = 'F';
		}
	}
	
	for (int i = 10; i < 20; i++)
	{
		for (int j = 30; j < 40; j++)
		{
			map[i][j][0] = 'G';
		}
	}
	
	for (int i = 30; i < 40; i++)
	{
		for (int j = 10; j < 20; j++)
		{
			map[i][j][0] = 'G';
		}
	}
}

void Map::buildObstacles(int value)
{
	for (int i = 0; i < 50; i++)
	{
		for (int j = 0; j < 50; j++)
		{
			if (map[i][j][0] == 'L')
			{
				if (rand() % value == 0)
				{
					map[i][j][0] = 'T';
				}
				else if (rand() % value == 1)
				{
					map[i][j][0] = 'R';
				}
				else if (rand() % value == 2)
				{
					map[i][j][0] = 'B';
				}
			}
		}
	}	
}

void Map::placeStore()
{
	int x;
	int y;
	
	for (int i = 0; i < 3; i++)
	{
		x = rand() % 40 + 5;
		y = rand() % 40 + 5;
		map[x][y][0] = '1';
	}
	
	for (int i = 0; i < 3; i++)
	{
		x = rand() % 40 + 5;
		y = rand() % 40 + 5;
		
		if (map[x][y][0] == '1')
		{
			i--;
		}
		else
		{ 
			map[x][y][0] = '2';	
		}		
	}
	
	for (int i = 0; i < 7; i++)
	{
		x = rand() % 40 + 5;
		y = rand() % 40 + 5;
		
		if ((map[x][y][0] == '1') || (map[x][y][0] == '2') )
		{
			i--;
		}
		else
		{
			map[x][y][0] = '3';	
		}				
	} 
}

void Map::printMap()
{
	cout << "======================================================================================================" << endl; 
	for (int i = 0; i < 50; i++)
	{
		cout  << "|";
		for (int j = 0; j < 50; j++)
		{
			if (map[i][j][2] != '0')
			{
				cout << "  ";
			}
			else
			{
				
			
			if (map[i][j][1] != '0')
			{
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_INTENSITY | BACKGROUND_BLUE | FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				cout << "Pl";
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
			}
			else
			{ 
				if (map[i][j][0] == 'L')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED | BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_RED);
					cout << map[i][j][1] << " ";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else if (map[i][j][0] == 'W')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_BLUE | FOREGROUND_BLUE);
					cout << map[i][j][1] << " ";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}	
				else if (map[i][j][0] == 'T')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_BLUE);
					cout << map[i][j][1] << " ";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else if (map[i][j][0] == 'R')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_INTENSITY | BACKGROUND_INTENSITY | FOREGROUND_INTENSITY | FOREGROUND_INTENSITY);
					cout << map[i][j][1] << " ";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else if (map[i][j][0] == 'B')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_RED | FOREGROUND_BLUE | BACKGROUND_RED | BACKGROUND_BLUE);
					cout << map[i][j][1] << " ";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else if (map[i][j][0] == 'F')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | BACKGROUND_GREEN | FOREGROUND_GREEN | BACKGROUND_GREEN);
					cout << map[i][j][1] << " ";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else if (map[i][j][0] == 'G')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | BACKGROUND_GREEN | FOREGROUND_RED | BACKGROUND_RED);
					cout << map[i][j][1] << " ";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else if (map[i][j][0] == '1')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_INTENSITY | FOREGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE);
					cout << "ST";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else if (map[i][j][0] == '2')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_INTENSITY | FOREGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE);
					cout << "BA";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
				else if (map[i][j][0] == '3')
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_INTENSITY | FOREGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE);
					cout << "$$";
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
				}
			}
			
			}
		}
		cout  << "|" << endl;
	}	
	cout << "======================================================================================================" << endl; 
	mapGuiding();			
}

void Map::mapGuiding()
{
	cout << "Terrains:                             Obstacles:                 Objects:" << endl;
	cout << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED | BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_RED);
	cout << "  ";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Land  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_BLUE | FOREGROUND_BLUE);
	cout << "  ";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Water  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | BACKGROUND_GREEN | FOREGROUND_GREEN | BACKGROUND_GREEN);
	cout << "  ";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Forest  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | BACKGROUND_GREEN | FOREGROUND_RED | BACKGROUND_RED);
	cout << "  ";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Bog  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_BLUE);
	cout << "  ";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Tree  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_INTENSITY | BACKGROUND_INTENSITY | FOREGROUND_INTENSITY | FOREGROUND_INTENSITY);
	cout << "  ";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Rock  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_RED | FOREGROUND_BLUE | BACKGROUND_RED | BACKGROUND_BLUE);
	cout << "  ";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Bush  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE);
	cout << "ST";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Store  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE);
	cout << "BA";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Bar  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_INTENSITY | BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE);
	cout << "$$";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);	
	cout << " Jewel  "; 
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_INTENSITY | BACKGROUND_BLUE | FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << "Pl";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	cout << " Player "; 
	cout << endl; 
	cout << endl;
}

void Map::setAllDark()
{
	for (int i = 0; i < 50; i++)
	{
		for (int j = 0; j < 50; j++)
		{
			map[i][j][2] = '1';
		}
	}	
}

void Map::setPlayer(int x, int y)
{
	map[x][y][1] = '1';
	map[x][y][2] = '0';
	map[x][y+1][2] = '0';
	map[x][y-1][2] = '0';
	map[x+1][y][2] = '0';
	map[x+1][y+1][2] = '0';
	map[x+1][y-1][2] = '0';
	map[x-1][y][2] = '0';
	map[x-1][y+1][2] = '0';
	map[x-1][y-1][2] = '0';
	
	if ((map[x][y][0] == 'B') || (map[x][y][0] == 'R') || (map[x][y][0] == 'T') || (map[x][y][0] == '3'))
	{
		map[x][y][0] = 'L';
	}
}

void Map::setPlayerSuper(int x, int y)
{
	map[x][y][1] = '1';
	map[x][y][2] = '0';
	map[x][y+1][2] = '0';
	map[x][y-1][2] = '0';
	map[x+1][y][2] = '0';
	map[x+1][y+1][2] = '0';
	map[x+1][y-1][2] = '0';
	map[x-1][y][2] = '0';
	map[x-1][y+1][2] = '0';
	map[x-1][y-1][2] = '0';
	
	map[x][y-2][2] = '0';
	map[x][y+2][2] = '0';
	map[x+1][y-2][2] = '0';
	map[x+1][y+2][2] = '0';
	map[x-1][y-2][2] = '0';
	map[x-1][y+2][2] = '0';
	
	map[x-2][y-2][2] = '0';
	map[x-2][y+2][2] = '0';
	map[x+2][y-2][2] = '0';
	map[x+2][y+2][2] = '0';
	
	map[x-2][y][2] = '0';
	map[x+2][y][2] = '0';
	map[x-2][y-1][2] = '0';
	map[x+2][y-1][2] = '0';
	map[x-2][y+1][2] = '0';
	map[x+2][y+1][2] = '0';
	
	if ((map[x][y][0] == 'B') || (map[x][y][0] == 'R') || (map[x][y][0] == 'T') || (map[x][y][0] == '3'))
	{
		map[x][y][0] = 'L';
	}
}
